const mahasiswaNim = "2022004020";
const updateData = {
  nama: "Ronaldo",
  gender: "L",
  prodi: "TE",
  alamat: "JL. Sukabumi-Cianjur",
};

//PUT
fetch(`http://localhost:3000/mahasiswa/${mahasiswaNim}`, {
  method: "PUT",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(updateData),
})
  .then((response) => response.json())
  .then((data) => console.log(data))
  .catch((error) => console.error("Error:", error));

// POST
const newMahasiswaData = {
  nim: "2022004021",
  nama: "Messi",
  gender: "L",
  prodi: "TI",
  alamat: "JL. Bandung-Jakarta",
};

fetch("http://localhost:3000/mahasiswa", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify(newMahasiswaData),
})
  .then((response) => response.json())
  .then((data) => console.log(data))
  .catch((error) => console.error("Error:", error));

// DELETE
const mahasiswaNimToDelete = "2022004021";

fetch(`http://localhost:3000/mahasiswa/${mahasiswaNimToDelete}`, {
  method: "DELETE",
})
  .then((response) => response.json())
  .then((data) => console.log(data))
  .catch((error) => console.error("Error:", error));
