const express = require("express");
const router = express.Router();
const db = require("../models/db");

// GET /dosen
router.get("/", (req, res) => {
  db.query("SELECT * FROM dosen", (error, results) => {
    if (error) {
      console.error("Error fetching mahasiswa:", error);
      res.status(500).json({ message: "Internal Server Error;" });
    } else {
      res.json(results);
    }
  });
});

//GET /dosen/;id
router.get("/:nim", (req, res) => {
  const dosenId = req.params.id;
  db.query("SELECT * FROM dosen WHERE id = ?", [dosenId], (error, results) => {
    if (error) {
      console.error("Error fetching dosen:", error);
      res.status(500).json({ message: "Internal Server Error" });
    } else if (results.length === 0) {
      res.status(404).json({ message: "Dosen not found" });
    } else {
      res.json(results[0]);
    }
  });
});

//PUT /dosen/:nim
router.put("/:id", (req, res) => {
  const dosenId = req.params.id;
  const { id, nama, gender, mata_kuliah, sks } = req.body;

  console.log("Received data:", req.body); //menambahkan console log

  db.query(
    "UPDATE dosen SET id = ?, nama = ?, gender = ?, mata_kuliah = ? WHERE id = ?",
    [id, nama, gender, mata_kuliah, dosenId],
    (error) => {
      if (error) {
        console.error("Error updating dosen:", error);
        res.status(500).json({ message: "Internal Server Error" });
      } else {
        res.json("Updating dosen Succesfully");
      }
    }
  );
});

// POST /dosen
router.post("/", (req, res) => {
  const { id, nama, gender, mata_kuliah, sks } = req.body;
  db.query(
    "INSERT INTO dosen (id, nama, gender, mata_kuliah, sks) VALUES (?, ?, ?, ?, ?)",
    [id, nama, gender, mata_kuliah, sks],
    (error) => {
      if (error) {
        console.error("Error adding dosen:", error);
        res.status(500).json({ message: "Internal Server Error" });
      } else {
        res.json({ message: "Dosen added successfully" });
      }
    }
  );
});

// DELETE /dosen/:id
router.delete("/:id", (req, res) => {
  const dosenId = req.params.id;
  db.query("DELETE FROM dosen WHERE id = ?", [dosenId], (error) => {
    if (error) {
      console.error("Error deleting dosen:", error);
      res.status(500).json({ message: "Internal Server Error" });
    } else {
      res.json({ message: "Dosen deleted successfully" });
    }
  });
});

module.exports = router;
